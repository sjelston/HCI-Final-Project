Since our project has culminated into a series of HTML files, there is no further compilation needed, simply open the HTML file with your preferred browser(Note: has only been tested with Chrome, Microsoft Edge, and Safari so those browsers are recommended for the optimal viewer experience).

There are two versions of our software that are each very similar. We have two Html files to represent an online version of the class(zoomHome.html and zoomResources.html) as well as two others to represent an in-person version of the same class(physicalHome.html and physicalResources.html).

